schema 이름은 prj2
pw는 chlcksdn0316!로 설정했습니다.

디버그 환경 x64이며
practice 폴더 -> [project2]20191662.sln로 실행시켜주시면 됩니다.

*practice 폴더 안에 dbfiletxt.txt라는 CRUD file 있습니다.