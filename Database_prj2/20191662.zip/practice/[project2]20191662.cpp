#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <mysql.h> 
#include <string.h> 
#include <stdlib.h> 
#include "mysql.h"
#define MAXLINE 10000
#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "chlcksdn0316!";
const char* db = "prj2";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;

	char rquery[MAXLINE]; 
	char buf[MAXLINE]; 


	int num, k;


	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");

	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		printf("Connection Succeed\n");

		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}
		FILE* fp = fopen("dbfiletxt.txt", "r");
		while (!feof(fp)) {
			fgets(buf, MAXLINE, fp);
			mysql_query(connection, buf);
		}

		fclose(fp);	
		int start;
		while (1) {
			printf("------- SELECT QUERY TYPES -------\n\n");
			printf("\t1. TYPE 1\n");
			printf("\t2. TYPE 2\n");
			printf("\t3. TYPE 3\n");
			printf("\t4. TYPE 4\n");
			printf("\t5. TYPE 5\n");
			printf("\t0. QUIT\n");
			printf("Type Select(1,2,3,4,5,0): ");
			scanf("%d", &num);
			start = 1;
			int year = 0;
			char s1[10];
			memset(s1, 0, sizeof(char) * 10);
			memset(rquery, 0, sizeof(char)*MAXLINE);
			switch (num) {
			case 1:
				printf("----- Subtypes in TYPE 1 -----\n");
				printf("\t1. TYPE 1-1\n");
				printf("\t2. TYPE 1-2\n");
				printf("\t3. TYPE 1-3\n");
				printf("Type Select(1,2,3): ");
				scanf("%d", &k);
				if (k == 1) {
					printf("---- TYPE 1-1 ----\n\n");
					printf("**Assume truck 1721 is destroyed in a crash. Find all customers who had a package on the truck at the time of the crash**\n");
			
					strcpy(rquery, "select distinct Customer.name from Delivery_Vehicle, Shipment, Cus_ship, Customer where Delivery_Vehicle.Vehicle_number = '1721' and Shipment.Shipment_ID = Delivery_Vehicle.Shipment_ID and Shipment.status = 'In Transit' and Cus_ship.Shipment_ID = Shipment.Shipment_ID and Cus_Ship.Customer_ID = Customer.Customer_ID");
					mysql_query(connection, rquery);
			
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%s\n", sql_row[0]);
						}
						mysql_free_result(sql_result);
				
				}
				else if (k == 2) {
					printf("---- TYPE 1-2 ----\n\n");
					printf("**Assume truck 1721 is destroyed in a crash. Find all recipients who had a package on that truck at the time of the crash**\n");
					strcpy(rquery, "select distinct Receipient.name from Delivery_Vehicle, Shipment, Rec_ship, Receipient where Delivery_Vehicle.Vehicle_number = '1721' and Shipment.Shipment_ID = Delivery_Vehicle.Shipment_ID and Shipment.status = 'In Transit' and Rec_ship.Shipment_ID = Shipment.Shipment_ID and Rec_Ship.Receipient_ID = Receipient.Receipient_ID");
					mysql_query(connection, rquery);
					
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%s\n", sql_row[0]);
						}
						mysql_free_result(sql_result);
				
				}
				else if (k == 3) {
					printf("**Assume truck 1721 is destroyed in a crash. Find the last successful delivery by that truck prior to the crash**\n");
					
					strcpy(rquery, "select max(Shipment.date) from Delivery_Vehicle, Shipment where Delivery_Vehicle.Vehicle_number = '1721' and Shipment.Shipment_ID = Delivery_Vehicle.Shipment_ID and (Shipment.status = 'Delivered(on time)' or Shipment.status = 'Delivered(delayed)')");
					 mysql_query(connection, rquery);
				
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%s\n", sql_row[0]);
						}
						mysql_free_result(sql_result);
			
				}
				break;
			case 2:
				printf("---- TYPE 2 ----\n\n");
				printf("**Find the customer who has shipped the most packages in the past year**\n");
				printf("Which year?(2021~2022): ");
				scanf("%d", &year);
				sprintf(s1, "%d", year);
				strcpy(rquery, "with F(FID,NUM) as(select K.CID ,count(K.CID) from(select Cus_ship.Customer_ID as CID from Cus_ship natural left outer join Shipment where Shipment.date like '");
				strcat(rquery, s1);
				strcat(rquery, "%')as K group by K.CID) select Customer.name from Customer,F where Customer.Customer_ID = F.FID and F.NUM = (select max(T1.NUM) from F as T1)");
				mysql_query(connection, rquery);
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%s\n", sql_row[0]);
					}
					mysql_free_result(sql_result);
			
				break;
			case 3:
				printf("---- TYPE 3 ----\n\n");
				printf("**Find the customer who has spent the most money on shipping in the past year**\n");
				printf("Which year?(2021~2022): ");
				scanf("%d", &year);
				sprintf(s1, "%d", year);
				strcpy(rquery, "with F(FID,NUM) as(select K.CID ,sum(K.C_COST)from(select Cus_ship.Customer_ID as CID, Shipment.cost as C_COST from Cus_ship natural left outer join Shipment where Shipment.date like '");
				strcat(rquery, s1);
				strcat(rquery, "%')as K group by K.CID) select Customer.name from Customer,F where Customer.Customer_ID = F.FID and F.NUM = (select max(T1.NUM) from F as T1)");
				mysql_query(connection, rquery);
				sql_result = mysql_store_result(connection);
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s\n", sql_row[0]);
				}
				mysql_free_result(sql_result);

				break;

			case 4:
				printf("---- TYPE 4 ----\n\n");
				printf("**Find those packages that were not delivered within the promised time**\n");
				strcpy(rquery, "select Package_Info.Package_name from Package_Info natural left outer join Shipment where Shipment.status='Delivered(delayed)'");
				mysql_query(connection, rquery);
				sql_result = mysql_store_result(connection);
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s\n", sql_row[0]);
				}
				mysql_free_result(sql_result);
				break;

			case 5:
				printf("---- TYPE 5 ----\n\n");
				printf("**Generate the bill for each customer for the past month. Consider creating several types of bills**\n");
				printf("Which month?(1,2,3,4,5): ");
				scanf("%d", &year);
				sprintf(s1, "%d", year);
				strcpy(rquery, "with F(FID,NUM) as(select K.CID ,sum(K.C_COST)from(select Cus_ship.Customer_ID as CID, Shipment.cost as C_COST from Cus_ship natural left outer join Shipment where Shipment.date like '20230");
				strcat(rquery, s1);
				strcat(rquery, "%')as K group by K.CID) select Customer.name, Customer.address, F.NUM from Customer,F  where Customer.Customer_ID = F.FID");
				mysql_query(connection, rquery);
				sql_result = mysql_store_result(connection);
				printf("<Simple bill-Customer name, Address, Amount Owed>\n");
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s	%s	%s\n", sql_row[0], sql_row[1], sql_row[2]);
				}
				mysql_free_result(sql_result);

				memset(rquery, 0, sizeof(char)*MAXLINE);
				strcpy(rquery, "with F(FID,FTID,FCOST) as(select K.CID , Ship_Service.service_type_ID,K.C_COST from(select Cus_ship.Customer_ID as CID, Shipment.Shipment_ID as SID, Shipment.cost as C_COST from Cus_ship natural left outer join Shipment where Shipment.date like '20230");
				strcat(rquery, s1);
				strcat(rquery, "%')as K, Ship_Service where K.SID= Ship_Service.Shipment_ID) select Customer.name, F.FTID, sum(FCOST) from Customer,F where Customer.Customer_ID = F.FID group by Customer.name,F.FTID");
				mysql_query(connection, rquery);
				sql_result = mysql_store_result(connection);
				printf("<A bill listing charges by type of service-Customer name, Service_Type_ID, Amount Owed>\n");
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s	%s	%s\n", sql_row[0], sql_row[1], sql_row[2]);
				}
				mysql_free_result(sql_result);

				memset(rquery, 0, sizeof(char)*MAXLINE);
				strcpy(rquery, "with F(FID,FTID,FCOST) as(select K.CID , K.SID,K.C_COST from(select Cus_ship.Customer_ID as CID, Shipment.Shipment_ID as SID, Shipment.cost as C_COST from Cus_ship natural left outer join Shipment where Shipment.date like '20230");
				strcat(rquery, s1);
				strcat(rquery, "%')as K) select Customer.name, F.FTID, sum(FCOST) from Customer,F where Customer.Customer_ID = F.FID group by Customer.name,F.FTID");
				mysql_query(connection, rquery);
				sql_result = mysql_store_result(connection);
				printf("<An itemize billing listing each individual shipment and the charges for it-Customer name, Shipment_ID, Amount Owed>\n");
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s	%s	%s\n", sql_row[0], sql_row[1], sql_row[2]);
				}
				mysql_free_result(sql_result);
				break;

			case 0:
				return 0;
				break;
			}
			while (start) {
				printf("Press 0 if you want to select another menu : ");
				scanf("%d", &start);
			}
		}	
		mysql_close(connection);
	}

	return 0;
}
